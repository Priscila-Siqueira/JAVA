
public class HelloWord {
	public static void main(String[] args) {
		System.out.println("Hello Word!");
		System.out.println("É o meu primeiro projeto.");
	}
}
