/**
 * 
 * @author 36134482024.2
 *
 */
public class HelloWord2 {
	public static void main(String[] args) {
		System.out.println("Parabéns você conseguiu!");
		
	}
}
