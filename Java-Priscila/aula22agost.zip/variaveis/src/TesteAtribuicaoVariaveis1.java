
public class TesteAtribuicaoVariaveis1 {

	public static void main(String[] args) {
		//Definição de variáveis
		boolean g;
		char c;
		byte b;
		short s;
		int i;
		long l;
		float f;
		double d;
		//Atribuição de variáveis
		g = true;
		c = '1';
		b = 0;
		s = 0;
		i = 0;
		l = 0;
		f = 0;
		d = 0;
		//Exibição de variáveis
		System.out.println("g="+g);
		System.out.println("c="+c);
		System.out.println("b="+b);
		System.out.println("s="+s);
		System.out.println("i="+i);
		System.out.println("l="+l);
		System.out.println("f="+f);
		System.out.println("d="+d);
	}

}
